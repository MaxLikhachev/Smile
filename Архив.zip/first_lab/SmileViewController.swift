//
//  ViewController.swift
//  first_lab
//
//  Created by Максим Лихачев on 02.03.2020.
//  Copyright © 2020 Максим Лихачев. All rights reserved.
//

import UIKit

class SmileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

